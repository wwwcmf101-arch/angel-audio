package com.angel.audio

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.nio.ByteBuffer
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/** One 10 ms block of mono audio. refUs = capture time in THIS phone's clock. */
internal class Pkt(val seq: Long, val refUs: Long, val samples: ShortArray)

internal fun nowUs() = System.nanoTime() / 1000

val BT_UUID: UUID = UUID.fromString("7a1f0b6e-8b3c-4d2a-9f31-a9e0a6c0a001")
private const val F_HELLO = 1
private const val F_AUDIO = 2
private const val F_PING = 3
private const val F_PONG = 4
private const val F_POS = 5      // phone -> main: where I would like to be
private const val F_ASSIGN = 6   // main -> phone: where you are
private const val F_BEEP = 7     // main -> phone: play a test sound
private const val F_LOC = 8      // phone -> main: shared position (only if the phone agreed)
private const val F_RING = 9     // main -> phone: ring loudly (repeated while wanted)
private const val F_STOPRING = 10

fun btAllowed(ctx: Context) = Build.VERSION.SDK_INT < 31 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

private fun frame(type: Int, payload: ByteArray): ByteArray {
    val b = ByteBuffer.allocate(3 + payload.size)          // big-endian: type, length, payload
    b.put(type.toByte()); b.putShort(payload.size.toShort()); b.put(payload)
    return b.array()
}

/** Main phone side: accepts up to 7 Bluetooth phones and feeds each one its channel as compressed audio. */
internal class BtHub(private val ctx: Context, private val scope: CoroutineScope, private val resolve: (String, Int) -> Int,
                       private val onLoc: (String) -> Unit) {
    private class Client(val sock: BluetoothSocket, @Volatile var pos: Int) {
        @Volatile var name = "Phone"
        @Volatile var reported = 8
        @Volatile var devId = ""
        val q = Channel<ByteArray>(24, BufferOverflow.DROP_OLDEST)
    }

    private val clients = ConcurrentHashMap<String, Client>()
    @Volatile private var server: BluetoothServerSocket? = null

    fun count() = clients.size
    fun hasPos(ch: Int) = clients.values.any { it.pos == ch }
    fun positions() = clients.values.map { it.pos }
    fun infos() = clients.map { (id, c) -> PhoneInfo(id, c.name, "Bluetooth", c.pos, c.reported, c.devId) }

    /** Re-checks every phone's placement (the main phone's user may have changed it) and tells the phone. */
    fun refresh() {
        for ((id, c) in clients) {
            val np = resolve(id, c.reported)
            if (np != c.pos) { c.pos = np; c.q.trySend(frame(F_ASSIGN, byteArrayOf(np.toByte()))) }
        }
    }

    fun sendRing(id: String, on: Boolean) { clients[id]?.q?.trySend(frame(if (on) F_RING else F_STOPRING, ByteArray(0))) }
    fun sendBeep(id: String) { clients[id]?.q?.trySend(frame(F_BEEP, ByteArray(0))) }

    @SuppressLint("MissingPermission")
    suspend fun serve() {
        val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
        if (adapter == null || !adapter.isEnabled) {
            AudioState.warning.value = "Bluetooth is off, so only Wi-Fi phones can join"; return
        }
        if (!btAllowed(ctx)) {
            AudioState.warning.value = "Bluetooth permission is missing, so only Wi-Fi phones can join"; return
        }
        val ss = adapter.listenUsingInsecureRfcommWithServiceRecord("AngelAudio", BT_UUID)
        server = ss
        try {
            while (currentCoroutineContext().isActive) {
                val s = ss.accept()
                scope.launch(Dispatchers.IO) { handle(s) }
            }
        } finally { try { ss.close() } catch (_: Exception) {} }
    }

    fun close() {
        try { server?.close() } catch (_: Exception) {}
        clients.values.forEach { try { it.sock.close() } catch (_: Exception) {} }
        clients.clear()
    }

    @SuppressLint("MissingPermission")
    private fun handle(sock: BluetoothSocket) {
        val key = sock.remoteDevice.address
        val c = Client(sock, 7)
        val inp = DataInputStream(BufferedInputStream(sock.inputStream))
        val out = BufferedOutputStream(sock.outputStream)
        val writer = scope.launch(Dispatchers.IO) {
            try { for (f in c.q) synchronized(out) { out.write(f); out.flush() } }
            catch (_: Exception) { try { sock.close() } catch (_: Exception) {} }
        }
        try {
            while (true) {
                val type = inp.readUnsignedByte()
                val len = inp.readUnsignedShort()
                val p = ByteArray(len); inp.readFully(p)
                when (type) {
                    F_HELLO, F_POS -> if (len >= 1) {
                        c.reported = p[0].toInt()
                        if (type == F_HELLO && len > 1) {
                            val s = String(p, 1, len - 1)
                            val i = s.indexOf('|')
                            if (i > 0) { c.devId = s.substring(0, i).take(64); c.name = s.substring(i + 1).take(40) } else c.name = s.take(40)
                        }
                        c.pos = resolve(key, c.reported)
                        clients[key] = c
                        c.q.trySend(frame(F_ASSIGN, byteArrayOf(c.pos.toByte())))
                    }
                    F_LOC -> onLoc(String(p))
                    F_PING -> if (len >= 8) {            // answer at once, ahead of queued audio, for an accurate clock
                        val b = ByteBuffer.allocate(16); b.put(p, 0, 8); b.putLong(nowUs())
                        synchronized(out) { out.write(frame(F_PONG, b.array())); out.flush() }
                    }
                }
            }
        } catch (_: Exception) {
        } finally {
            clients.remove(key); writer.cancel(); c.q.close()
            try { sock.close() } catch (_: Exception) {}
        }
    }

    /** samples = 480 samples at 48 kHz. Sent at 24 kHz ADPCM, about 12 KB/s per phone. */
    fun sendAudio(ch: Int, seq: Long, refUs: Long, samples: ShortArray) {
        var payload: ByteArray? = null
        for (c in clients.values) {
            if (c.pos != ch) continue
            if (payload == null) {
                val half = ShortArray(samples.size / 2) { ((samples[2 * it] + samples[2 * it + 1]) / 2).toShort() }
                val enc = Adpcm.encode(half)
                val b = ByteBuffer.allocate(14 + enc.size)
                b.putInt(seq.toInt()); b.putLong(refUs); b.putShort(half.size.toShort()); b.put(enc)
                payload = frame(F_AUDIO, b.array())
            }
            c.q.trySend(payload)
        }
    }
}

/** Extra phone side: connects to the main phone over Bluetooth and plays what it receives. */
internal class BtPeer(private val ctx: Context, private val queue: Channel<Pkt>) {
    @SuppressLint("MissingPermission")
    suspend fun run() {
        val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
        check(adapter != null && adapter.isEnabled) { "Turn Bluetooth on" }
        check(btAllowed(ctx)) { "Bluetooth permission is missing" }
        while (currentCoroutineContext().isActive && AudioState.btHubAddr.value.isEmpty()) {
            AudioState.status.value = "Choose the main phone first"; delay(1000)
        }
        val addr = AudioState.btHubAddr.value
        val name = AudioState.btHubName.value.ifEmpty { addr }
        AudioState.status.value = "Connecting to $name…"
        adapter.cancelDiscovery()
        val sock = adapter.getRemoteDevice(addr).createInsecureRfcommSocketToServiceRecord(BT_UUID)
        try {
            withContext(Dispatchers.IO) { sock.connect() }
            AudioState.status.value = "Connected to $name, syncing…"
            session(sock)
        } finally {
            AudioState.pcConnected.value = false
            AudioState.assignedPos.value = -1
            try { sock.close() } catch (_: Exception) {}
        }
    }

    private suspend fun session(sock: BluetoothSocket) = coroutineScope {
        val inp = DataInputStream(BufferedInputStream(sock.inputStream))
        val out = BufferedOutputStream(sock.outputStream)
        fun send(type: Int, p: ByteArray) = synchronized(out) { out.write(frame(type, p)); out.flush() }
        send(F_HELLO, byteArrayOf(AudioState.position.value.toByte()) + "${AudioState.devId.value}|${Build.MODEL.replace('|', ' ')}".toByteArray())

        var offsetUs = 0L
        var synced = false
        val recent = ArrayList<Pair<Long, Long>>()      // (round trip, offset) of the last pongs
        var last = 0                                     // previous sample, for smooth upsampling

        val pinger = launch(Dispatchers.IO) {
            var lastPos = AudioState.position.value
            var n = 0
            var lastLoc = 0L
            try {
                while (isActive) {
                    send(F_PING, ByteBuffer.allocate(8).putLong(nowUs()).array())
                    if (AudioState.position.value != lastPos) {
                        lastPos = AudioState.position.value; send(F_POS, byteArrayOf(lastPos.toByte()))
                    }
                    if (System.currentTimeMillis() - lastLoc > 15_000) {
                        locPayload(ctx)?.let { send(F_LOC, it.toByteArray()) }
                        lastLoc = System.currentTimeMillis()
                    }
                    delay(if (n++ < 5) 250L else 3000L)
                }
            } catch (_: Exception) { try { sock.close() } catch (_: Exception) {} }
        }
        try {
            while (isActive) {
                val type = withContext(Dispatchers.IO) { inp.readUnsignedByte() }
                val len = inp.readUnsignedShort()
                val p = ByteArray(len); inp.readFully(p)
                val bb = ByteBuffer.wrap(p)
                when (type) {
                    F_ASSIGN -> if (len >= 1) AudioState.assignedPos.value = p[0].toInt()
                    F_BEEP -> launch { playTestTone(AudioState.gainPercent.value / 100f) }
                    F_RING -> Ringer.ring()
                    F_STOPRING -> Ringer.stop()
                    F_PONG -> if (len >= 16) {
                        val t1 = bb.long; val t2 = bb.long; val t4 = nowUs()
                        recent.add((t4 - t1) to (t2 - (t1 + t4) / 2))
                        if (recent.size > 6) recent.removeAt(0)
                        offsetUs = recent.minByOrNull { it.first }!!.second   // the quickest round trip is the most trustworthy
                        synced = true
                    }
                    F_AUDIO -> if (synced && len >= 14) {
                        val seq = bb.int.toLong() and 0xFFFFFFFFL
                        val refUs = bb.long
                        val n = bb.short.toInt() and 0xFFFF
                        if (len < 14 + 3 + (n + 1) / 2) continue
                        val half = Adpcm.decode(p, 14, n)
                        val up = ShortArray(n * 2)
                        var prev = last
                        for (i in 0 until n) { val cur = half[i].toInt(); up[2 * i] = ((prev + cur) / 2).toShort(); up[2 * i + 1] = cur.toShort(); prev = cur }
                        last = prev
                        AudioState.pcConnected.value = true
                        AudioState.warning.value = ""
                        AudioState.status.value = "Playing as ${AudioState.shownName()} (Bluetooth)"
                        queue.trySend(Pkt(seq, refUs - offsetUs, up))
                    }
                }
            }
        } finally { pinger.cancel(); try { sock.close() } catch (_: Exception) {} }
    }
}
