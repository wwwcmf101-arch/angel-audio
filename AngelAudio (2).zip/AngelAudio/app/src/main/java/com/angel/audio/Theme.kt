package com.angel.audio

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Orange = Color(0xFFFF7A00)
val Graphite = Color(0xFF1A1A1A)
val TrackGrey = Color(0xFF3A3A3A)

@Composable
fun AngelTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Orange, onPrimary = Color.Black,
            primaryContainer = Color(0xFF3A1D00), onPrimaryContainer = Color.White,
            secondary = Orange, onSecondary = Color.Black,
            secondaryContainer = Color(0xFF3A1D00), onSecondaryContainer = Color.White,
            tertiary = Orange, onTertiary = Color.Black,
            background = Color.Black, onBackground = Color.White,
            surface = Color.Black, onSurface = Color.White,
            surfaceVariant = Graphite, onSurfaceVariant = Color(0xFFE0E0E0),
            outline = Color(0xFF666666), outlineVariant = Color(0xFF333333),
            error = Orange, onError = Color.Black
        ),
        content = content
    )
}
