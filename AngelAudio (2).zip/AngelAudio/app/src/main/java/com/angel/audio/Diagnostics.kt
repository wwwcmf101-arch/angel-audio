package com.angel.audio

import android.content.Context
import android.util.Log

/** If the app ever closes unexpectedly, keep the reason so the next launch can offer to copy it. */
fun installCrashLogger(ctx: Context) {
    val prev = Thread.getDefaultUncaughtExceptionHandler()
    if (prev is CrashLogger) return
    Thread.setDefaultUncaughtExceptionHandler(CrashLogger(ctx.applicationContext, prev))
}

private class CrashLogger(val ctx: Context, val prev: Thread.UncaughtExceptionHandler?) : Thread.UncaughtExceptionHandler {
    override fun uncaughtException(t: Thread, e: Throwable) {
        try {
            val text = Log.getStackTraceString(e).take(3000) + "\n--- recent events ---\n" + AudioState.logText()
            ctx.getSharedPreferences("angel", Context.MODE_PRIVATE).edit().putString("lastcrash", text).commit()
        } catch (_: Throwable) {}
        prev?.uncaughtException(t, e)
    }
}
