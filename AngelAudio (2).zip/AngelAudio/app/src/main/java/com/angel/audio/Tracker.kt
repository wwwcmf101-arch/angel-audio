package com.angel.audio

import android.content.Context
import android.media.*
import android.os.BatteryManager
import android.os.Build
import kotlinx.coroutines.*
import kotlin.math.PI
import kotlin.math.sin

/** "devId|name|lat|lon|accuracy|battery|ageMs" - what an extra phone shares, only if its owner agreed. */
internal fun locPayload(ctx: Context): String? {
    if (!AudioState.shareLocation.value) return null
    val f = AudioState.lastFix.value ?: return null
    val bat = try {
        (ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    } catch (_: Exception) { -1 }
    return "${AudioState.devId.value}|${Build.MODEL.replace('|', ' ')}|${f.lat}|${f.lon}|${f.acc}|$bat|${System.currentTimeMillis() - f.timeMs}"
}

/** Checks everything, because this text arrives from the network. */
internal fun parseLoc(payload: String, via: String): Tracked? {
    val p = payload.split("|")
    if (p.size < 7 || p[0].length !in 8..64) return null
    return try {
        val lat = p[2].toDouble(); val lon = p[3].toDouble()
        if (lat !in -90.0..90.0 || lon !in -180.0..180.0) return null
        val now = System.currentTimeMillis()
        Tracked(p[0], p[1].take(40), lat, lon, p[4].toFloat(), now - p[6].toLong().coerceAtLeast(0), now,
            p[5].toInt().coerceIn(-1, 100), via)
    } catch (_: Exception) { null }
}

/** Loud siren on the alarm channel, so a lost phone can be heard even when it is on silent. */
object Ringer {
    private var ctx: Context? = null
    private var scope: CoroutineScope? = null
    private var job: Job? = null
    @Volatile private var lastMsg = 0L
    @Volatile private var suppressUntil = 0L

    fun attach(c: Context, s: CoroutineScope) { ctx = c.applicationContext; scope = s }

    /** Called again every few seconds while the main phone still wants this phone to ring. */
    @Synchronized
    fun ring() {
        val now = System.currentTimeMillis()
        if (now < suppressUntil) return
        lastMsg = now
        if (job?.isActive == true) return
        val c = ctx ?: return
        val s = scope ?: return
        job = s.launch(Dispatchers.IO) { siren(c) }
    }

    /** The person holding the phone tapped Stop: stay quiet for a minute even if asked again. */
    fun stopByOwner() { suppressUntil = System.currentTimeMillis() + 60_000; stop() }

    @Synchronized
    fun stop() { job?.cancel(); job = null; AudioState.ringing.value = false }

    private suspend fun siren(c: Context) {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val oldVolume = am.getStreamVolume(AudioManager.STREAM_ALARM)
        try { am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0) } catch (_: Exception) {}
        val rate = 44100
        val buf = ShortArray(rate / 10)
        val track = AudioTrack(
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build(),
            AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build(),
            buf.size * 4, AudioTrack.MODE_STREAM, AudioManager.AUDIO_SESSION_ID_GENERATE
        )
        AudioState.ringing.value = true
        try {
            track.play()
            var phase = 0.0
            var t = 0L
            while (currentCoroutineContext().isActive && System.currentTimeMillis() - lastMsg < 10_000) {
                for (i in buf.indices) {
                    val f = 900 + 500 * sin(2 * PI * 1.5 * t / rate)      // sweeping 400-1400 Hz, hard to miss
                    phase = (phase + 2 * PI * f / rate) % (2 * PI)
                    buf[i] = (sin(phase) * 0.95 * 32767).toInt().toShort()
                    t++
                }
                if (track.write(buf, 0, buf.size) < 0) break
            }
        } finally {
            try { track.release() } catch (_: Exception) {}
            try { am.setStreamVolume(AudioManager.STREAM_ALARM, oldVolume, 0) } catch (_: Exception) {}
            AudioState.ringing.value = false
        }
    }
}
