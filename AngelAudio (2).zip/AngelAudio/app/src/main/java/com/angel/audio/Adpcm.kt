package com.angel.audio

import kotlin.math.abs

/** IMA ADPCM: 4 bits per sample. Each block carries its own start state, so a lost block never hurts the next one. */
object Adpcm {
    private val STEP = intArrayOf(
        7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88,
        97, 107, 118, 130, 143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658,
        724, 796, 876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660,
        4026, 4428, 4871, 5358, 5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899, 15289, 16818,
        18500, 20350, 22385, 24623, 27086, 29794, 32767
    )
    private val INDEX = intArrayOf(-1, -1, -1, -1, 2, 4, 6, 8)

    /** Output: 2 bytes start value, 1 byte start step index, then packed 4-bit codes. */
    fun encode(s: ShortArray): ByteArray {
        val out = ByteArray(3 + (s.size + 1) / 2)
        var pred = if (s.isEmpty()) 0 else s[0].toInt()
        // Start the step size near the block's loudness so the first samples are not coarse.
        var sum = 0L
        for (i in 1 until s.size) sum += abs(s[i] - s[i - 1])
        val avg = if (s.size > 1) sum / (s.size - 1) else 0L
        var idx = 0
        while (idx < 88 && STEP[idx] * 2L < avg) idx++
        out[0] = (pred shr 8).toByte(); out[1] = pred.toByte(); out[2] = idx.toByte()
        var low = 0
        for (i in s.indices) {
            var diff = s[i] - pred
            var code = 0
            if (diff < 0) { code = 8; diff = -diff }
            var step = STEP[idx]
            var vp = step shr 3
            if (diff >= step) { code = code or 4; diff -= step; vp += step }
            step = step shr 1
            if (diff >= step) { code = code or 2; diff -= step; vp += step }
            step = step shr 1
            if (diff >= step) { code = code or 1; vp += step }
            pred = (if (code and 8 != 0) pred - vp else pred + vp).coerceIn(-32768, 32767)
            idx = (idx + INDEX[code and 7]).coerceIn(0, 88)
            if (i % 2 == 0) low = code else out[3 + i / 2] = (low or (code shl 4)).toByte()
        }
        if (s.size % 2 == 1) out[3 + s.size / 2] = low.toByte()
        return out
    }

    fun decode(d: ByteArray, off: Int, n: Int): ShortArray {
        var pred = (d[off].toInt() shl 8) or (d[off + 1].toInt() and 0xFF)
        pred = pred.toShort().toInt()
        var idx = (d[off + 2].toInt() and 0xFF).coerceIn(0, 88)
        val out = ShortArray(n)
        for (i in 0 until n) {
            val b = d[off + 3 + i / 2].toInt() and 0xFF
            val code = if (i % 2 == 0) b and 0xF else b shr 4
            val step = STEP[idx]
            var vp = step shr 3
            if (code and 4 != 0) vp += step
            if (code and 2 != 0) vp += step shr 1
            if (code and 1 != 0) vp += step shr 2
            pred = (if (code and 8 != 0) pred - vp else pred + vp).coerceIn(-32768, 32767)
            idx = (idx + INDEX[code and 7]).coerceIn(0, 88)
            out[i] = pred.toShort()
        }
        return out
    }
}
