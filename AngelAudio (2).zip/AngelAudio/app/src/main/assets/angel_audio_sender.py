"""Angel Audio - PC sender. Captures what your computer plays and sends one channel per phone."""
import re, socket, struct, subprocess, sys, threading, time, warnings
import numpy as np

RATE, FRAME = 48000, 480                      # 10 ms packets
PORT_DISCOVERY, PORT_AUDIO, PORT_SYNC, PORT_HUB = 49500, 49501, 49502, 49503
HUB_IP = "__HUB_IP__"                         # the phone fills this in when you download the file
phones = {}                                   # direct mode only: ip -> (name, channel, last_seen)
state = {"off": None, "hub": None}            # hub clock minus PC clock (microseconds), and the hub phone address


def now_us():
    return int(time.perf_counter() * 1e6)


def hub_address():
    if len(sys.argv) > 1:
        return sys.argv[1]
    return None if HUB_IP.startswith("__") else HUB_IP


def to_seven(x):
    """Map captured audio to 8 columns: FL FR C SL SR RL RR and SOLO (a full mono mix for a single phone)."""
    n = x.shape[1]
    if n >= 6:                                # 5.1 / 7.1 source: FL FR C LFE SL SR [BL BR]
        sl, sr = x[:, 4], x[:, 5]
        bl = x[:, 6] if n >= 8 else sl
        br = x[:, 7] if n >= 8 else sr
        solo = 0.5 * (x[:, 0] + x[:, 1]) + 0.5 * x[:, 2]
        return np.stack([x[:, 0], x[:, 1], x[:, 2], sl, sr, bl, br, solo], axis=1)
    l = x[:, 0]
    r = x[:, 1] if n > 1 else x[:, 0]
    return np.stack([l, r, 0.7 * (l + r) / 2, l, r, 0.8 * l, 0.8 * r, (l + r) / 2], axis=1)


def pcm(col):
    return (np.clip(col, -1, 1) * 32767).astype("<i2").tobytes()


def hub_packets(seq, t, ch7):
    """One packet per channel (0-6 positions, 7 solo) for the hub phone: seq, time, samples, channel."""
    return [struct.pack("<IqHB", seq & 0xFFFFFFFF, t, ch7.shape[0], i) + pcm(ch7[:, i]) for i in range(8)]


def direct_packet(seq, t, ch7, idx):
    return struct.pack("<IqH", seq & 0xFFFFFFFF, t, ch7.shape[0]) + pcm(ch7[:, idx % 8])


def ping_offset(sock, addr, tries=8):
    """NTP-style: returns (best_rtt, other_clock - my_clock) or None."""
    best = None
    for _ in range(tries):
        try:
            t1 = now_us()
            sock.sendto(f"T|{t1}".encode(), addr)
            d, _ = sock.recvfrom(128)
            t4 = now_us()
            p = d.decode().split("|")
            if len(p) == 3 and p[0] == "R" and int(p[1]) == t1:
                rtt, off = t4 - t1, int(p[2]) - (t1 + t4) // 2
                if best is None or rtt < best[0]:
                    best = (rtt, off)
        except (socket.timeout, ValueError):
            pass
        time.sleep(0.04)
    return best


def parse_gateways(text):
    """IPv4 addresses after 'Default Gateway' (Windows ipconfig) or 'default via' (Linux)."""
    ips = []
    for m in re.finditer(r"Default Gateway", text):
        ips += re.findall(r"\d{1,3}(?:\.\d{1,3}){3}", text[m.end():m.end() + 120].split("\n\n")[0])
    ips += re.findall(r"default via (\d{1,3}(?:\.\d{1,3}){3})", text)
    return ips


def candidate_hubs(first):
    """The address baked into the file first, then the computer's gateways (a USB-tethered phone is one)."""
    found = [first] if first else []
    for cmd in (["ipconfig"], ["ip", "route"]):
        try:
            found += parse_gateways(subprocess.run(cmd, capture_output=True, text=True, timeout=5).stdout)
        except Exception:
            pass
    out = []
    for ip in found:
        if ip not in out and not ip.startswith("127."):
            out.append(ip)
    return out


def find_hub(cands, sock):
    for ip in cands:
        r = ping_offset(sock, (ip, PORT_SYNC), tries=3)
        if r:
            return ip, r[1]
    return None, None


def hub_clock_loop(cands):
    """Keeps the clock offset fresh. If the phone goes quiet, searches for it again (its address can change)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.settimeout(0.4)
    misses = 0
    while True:
        hub = state["hub"]
        r = ping_offset(s, (hub, PORT_SYNC)) if hub else None
        if r:
            state["off"], misses = r[1], 0
        else:
            misses += 1
            if misses >= 2:
                ip, off = find_hub(cands, s)
                if ip:
                    state["hub"], state["off"], misses = ip, off, 0
                    print(f"Phone found at {ip}")
        time.sleep(3)


def discovery():                              # direct mode (PC and phones on the same Wi-Fi)
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(("", PORT_DISCOVERY))
    while True:
        data, (ip, _) = s.recvfrom(256)
        p = data.decode(errors="ignore").split("|")
        if len(p) == 3 and p[0] == "ANGELSPK" and p[2].isdigit():
            if ip not in phones:
                print(f"+ {p[1]} joined ({ip})")
            phones[ip] = (p[1], int(p[2]), time.time())


def timesync_server():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind(("", PORT_SYNC))
    while True:
        data, addr = s.recvfrom(128)
        p = data.decode(errors="ignore").split("|")
        if len(p) == 2 and p[0] == "T":
            s.sendto(f"R|{p[1]}|{now_us()}".encode(), addr)


def capture_loop(mic, nch, out, use_hub):
    seq = 0
    with mic.recorder(samplerate=RATE, channels=nch, blocksize=FRAME) as rec:
        while True:
            ch7 = to_seven(rec.record(numframes=FRAME))
            try:
                if use_hub:
                    hub, off = state["hub"], state["off"]
                    if hub is None or off is None:
                        continue                      # phone not found yet
                    t = now_us() + off                # timestamp in the hub phone's clock
                    for pk in hub_packets(seq, t, ch7):
                        out.sendto(pk, (hub, PORT_HUB))
                else:
                    t = now_us()
                    for ip, (_, idx, seen) in list(phones.items()):
                        if time.time() - seen > 6:
                            phones.pop(ip, None); print(f"- {ip} left"); continue
                        out.sendto(direct_packet(seq, t, ch7, idx), (ip, PORT_AUDIO))
            except OSError:
                time.sleep(0.2)                       # network blip (cable moved, Wi-Fi roam): keep going
            seq += 1


def main():
    warnings.filterwarnings("ignore")
    import soundcard as sc
    first = hub_address()
    use_hub = first is not None
    out = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    if use_hub:
        cands = candidate_hubs(first)
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); probe.settimeout(0.4)
        print("Looking for your phone ...")
        for _ in range(20):
            ip, off = find_hub(cands, probe)
            if ip:
                state["hub"], state["off"] = ip, off
                print(f"Connected to your phone at {ip}")
                break
            time.sleep(1.5); cands = candidate_hubs(first)
        else:
            print("Cannot reach the phone. Is USB tethering on and Angel Audio started on the phone?")
            input("Press Enter to close")
            return
        threading.Thread(target=hub_clock_loop, args=(cands,), daemon=True).start()
    else:
        threading.Thread(target=discovery, daemon=True).start()
        threading.Thread(target=timesync_server, daemon=True).start()
    while True:                                       # audio problems restart the capture instead of ending the program
        try:
            spk = sc.default_speaker()
            mic = sc.get_microphone(str(spk.name), include_loopback=True)
            nch = min(max(getattr(spk, "channels", 2), 2), 8)
            print(f"Capturing: {spk.name} ({nch} ch). Play something! Press Ctrl+C to stop.")
            capture_loop(mic, nch, out, use_hub)
        except KeyboardInterrupt:
            raise
        except Exception as e:
            print("Audio problem:", e, "- trying again in 2 seconds")
            time.sleep(2)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
