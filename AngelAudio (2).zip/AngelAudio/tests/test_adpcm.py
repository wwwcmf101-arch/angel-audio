# Mirror of Adpcm.kt: verifies the algorithm, tables and 24 kHz down/up path
import numpy as np, re, os
src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'app/src/main/java/com/angel/audio/Adpcm.kt')).read()
STEP = [int(x) for x in re.search(r'STEP = intArrayOf\((.*?)\)', src, re.S).group(1).replace('\n',' ').split(',')]
INDEX = [-1,-1,-1,-1,2,4,6,8]
assert len(STEP)==89 and STEP[0]==7 and STEP[-1]==32767 and all(b>a for a,b in zip(STEP,STEP[1:]))
clamp=lambda v,a,b:max(a,min(b,v))
def enc(s):
    pred=int(s[0])
    avg=sum(abs(int(s[i])-int(s[i-1])) for i in range(1,len(s)))//max(1,len(s)-1)
    idx=0
    while idx<88 and STEP[idx]*2<avg: idx+=1
    out=bytearray([(pred>>8)&255,pred&255,idx]); low=0; body=bytearray((len(s)+1)//2)
    for i,x in enumerate(s):
        diff=int(x)-pred; code=0
        if diff<0: code=8; diff=-diff
        step=STEP[idx]; vp=step>>3
        if diff>=step: code|=4; diff-=step; vp+=step
        step>>=1
        if diff>=step: code|=2; diff-=step; vp+=step
        step>>=1
        if diff>=step: code|=1; vp+=step
        pred=clamp(pred-vp if code&8 else pred+vp,-32768,32767); idx=clamp(idx+INDEX[code&7],0,88)
        if i%2==0: low=code
        else: body[i//2]=low|(code<<4)
    if len(s)%2: body[len(s)//2]=low
    return bytes(out)+bytes(body)
def dec(d,n):
    pred=(d[0]<<8)|d[1]; pred=pred-65536 if pred>=32768 else pred; idx=d[2]; o=[]
    for i in range(n):
        b=d[3+i//2]; code=b&15 if i%2==0 else b>>4
        step=STEP[idx]; vp=step>>3
        if code&4: vp+=step
        if code&2: vp+=step>>1
        if code&1: vp+=step>>2
        pred=clamp(pred-vp if code&8 else pred+vp,-32768,32767); idx=clamp(idx+INDEX[code&7],0,88); o.append(pred)
    return np.array(o)
t=np.arange(240)/24000
for name,sig in [("440Hz",0.5*np.sin(2*np.pi*440*t)),("2kHz",0.3*np.sin(2*np.pi*2000*t)),("noise",np.random.uniform(-.3,.3,240))]:
    s=(sig*32767).astype(int); e=enc(s); r=dec(e,240)
    snr=10*np.log10(np.sum(s**2)/np.sum((s-r)**2))
    print(f"{name}: {len(e)} bytes/10ms block, SNR {snr:.1f} dB")
    if name!="noise": assert snr>18
print("bandwidth per phone: %.1f KB/s (+framing), 7 phones: %.0f KB/s" % (len(e)*100/1000, len(e)*700/1000))
# odd length block
assert len(dec(enc(np.arange(7)*100),7))==7
print("adpcm ok")
