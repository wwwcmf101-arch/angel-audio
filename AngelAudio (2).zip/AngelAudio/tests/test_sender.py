import socket, struct, threading, time, sys, types
import numpy as np
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'pc_sender'))
import angel_audio_sender as s

# 1) channel mapping
st = np.random.uniform(-1, 1, (480, 2)).astype('f4')
c7 = s.to_seven(st); assert c7.shape == (480, 8)
x8 = np.random.uniform(-1, 1, (480, 8)).astype('f4'); assert s.to_seven(x8).shape == (480, 8)
assert np.allclose(s.to_seven(x8)[:, 5], x8[:, 6])
print("mapping ok")

# 2) hub packets: format the Kotlin side parses (seq u32, t i64, n u16, ch u8, pcm)
pk = s.hub_packets(7, 123456789, c7)
assert len(pk) == 8 and len(pk[0]) == 15 + 960 < 1400
seq, t, n, ch = struct.unpack("<IqHB", pk[3][:15]); assert (seq, t, n, ch) == (7, 123456789, 480, 3)
pcm = np.frombuffer(pk[3][15:], '<i2'); assert len(pcm) == 480
print("hub packet ok", len(pk[0]), "bytes")

# 3) direct packet
dp = s.direct_packet(9, 55, c7, 2); assert struct.unpack("<IqH", dp[:14]) == (9, 55, 480) and len(dp) == 14 + 960
print("direct packet ok")

# 4) clock sync against a fake hub whose clock is 5 s ahead
HUB_SKEW = 5_000_000
srv = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); srv.bind(("127.0.0.1", 0)); port = srv.getsockname()[1]
def hub():
    while True:
        d, a = srv.recvfrom(128); p = d.decode().split("|")
        srv.sendto(f"R|{p[1]}|{s.now_us() + HUB_SKEW}".encode(), a)
threading.Thread(target=hub, daemon=True).start()
c = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); c.settimeout(0.4)
r = s.ping_offset(c, ("127.0.0.1", port))
assert r and abs(r[1] - HUB_SKEW) < 3000, r
print("clock sync ok, error us:", abs(r[1] - HUB_SKEW))

# 5) unreachable hub -> ping_offset returns None (no crash)
dead = socket.socket(); dead.close()
assert s.ping_offset(c, ("127.0.0.1", 9), tries=2) is None
print("dead hub ok")

# 6) gateway discovery parsing (Windows + Linux output)
win = """Ethernet adapter Ethernet 3:

   Connection-specific DNS Suffix  . :
   IPv6 Address. . . . . . . . . . . : fe80::1
   Default Gateway . . . . . . . . . : fe80::abcd%12
                                       192.168.42.129

Wireless LAN adapter Wi-Fi:

   Default Gateway . . . . . . . . . : 192.168.1.1
"""
g = s.parse_gateways(win); assert "192.168.42.129" in g and "192.168.1.1" in g, g
assert s.parse_gateways("default via 10.0.0.1 dev eth0") == ["10.0.0.1"]
print("gateway parse ok", g)
